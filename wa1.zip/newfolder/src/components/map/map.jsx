import styles from './map.module.css'

export default function Map() {
    return <div className={styles.map}>
        <img src="https://media.wired.com/photos/59269cd37034dc5f91bec0f1/191:100/w_1280,c_limit/GoogleMapTA.jpg"
             alt=""/>
    </div>
}